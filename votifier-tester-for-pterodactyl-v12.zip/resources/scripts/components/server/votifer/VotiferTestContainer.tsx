import React, { useState } from 'react';
import { ServerContext } from '@/state/server';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { sendClassicVotifierVote, sendNuVotifierVote, sendNuVotifierV2Vote } from '@/api/server/votifer/sendVote';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import { Alert } from '@/components/elements/alert/index';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import { Formik, Form, Field as FormikField, FormikHelpers, useFormikContext } from 'formik';
import * as Yup from 'yup';
import { Button } from '@/components/elements/button/index';
import tw from 'twin.macro';
import Label from '@/components/elements/Label';
import FormikFieldWrapper from '@/components/elements/FormikFieldWrapper';
import Input from '@/components/elements/Input';
import Select from '@/components/elements/Select';

interface Values {
    host: string;
    port: string;
    publicKey: string;
    token: string;
    username: string;
    voteType: string;
}

const VotifierTestBox = () => {
    const { isSubmitting, values, setFieldValue } = useFormikContext<Values>();

    return (
        <TitledGreyBox title={'Votifier Test'} css={tw`relative`}>
            <SpinnerOverlay visible={isSubmitting} />
            <Form css={tw`mb-0`}>
                <div css={tw`grid grid-cols-1 md:grid-cols-2 gap-6`}>
                    <div>
                        <Label htmlFor="host">Host</Label>
                        <FormikFieldWrapper name="host">
                            <FormikField as={Input} name="host" type="text" placeholder="Enter the host address" />
                        </FormikFieldWrapper>
                    </div>
                    <div>
                        <Label htmlFor="port">Port</Label>
                        <FormikFieldWrapper name="port">
                            <FormikField as={Input} name="port" type="text" placeholder="Enter the port" />
                        </FormikFieldWrapper>
                    </div>
                </div>
                <div css={tw`mt-6`}>
                    <Label htmlFor="username">Username</Label>
                    <FormikFieldWrapper name="username">
                        <FormikField as={Input} name="username" type="text" placeholder="Enter the username" />
                    </FormikFieldWrapper>
                </div>
                {values.voteType !== 'nuvotifierv2' && (
                    <div css={tw`mt-6`}>
                        <Label htmlFor="publicKey">Public Key</Label>
                        <FormikFieldWrapper name="publicKey">
                            <FormikField as={Input} name="publicKey" type="text" placeholder="Enter the public key" />
                        </FormikFieldWrapper>
                    </div>
                )}
                {values.voteType === 'nuvotifierv2' && (
                    <div css={tw`mt-6`}>
                        <Label htmlFor="token">Token</Label>
                        <FormikFieldWrapper name="token">
                            <FormikField as={Input} name="token" type="text" placeholder="Enter the token" />
                        </FormikFieldWrapper>
                    </div>
                )}
                <div css={tw`mt-6`}>
                    <Label htmlFor="voteType">Vote Type</Label>
                    <Select
                        name="voteType"
                        value={values.voteType}
                        onChange={e => setFieldValue('voteType', e.target.value)}
                        css={tw`mt-1 block w-full border border-gray-300 rounded-md shadow-sm`}
                    >
                        <option value="classic">Classic Votifier (Public Key)</option>
                        <option value="nuvotifier">NuVotifier (Public Key)</option>
                        <option value="nuvotifierv2">NuVotifier v2 (Token/Key)</option>
                    </Select>
                </div>
                <div css={tw`mt-6 text-right`}>
                    <Button type="submit" disabled={isSubmitting}>
                        Send Test Vote
                    </Button>
                </div>
            </Form>
        </TitledGreyBox>
    );
};

const VotifierTestContainer: React.FC = () => {
    const uuid = ServerContext.useStoreState(state => state.server.data!.uuid);
    const [isLoading, setIsLoading] = useState(false);
    const [response, setResponse] = useState<{ message?: string; error?: string } | null>(null);

    const submit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {
        setIsLoading(true);
        setResponse(null);

        const votePromise =
            values.voteType === 'classic'
                ? sendClassicVotifierVote(uuid, values.host, values.port, values.publicKey, values.username)
                : values.voteType === 'nuvotifier'
                    ? sendNuVotifierVote(uuid, values.host, values.port, values.publicKey, values.username)
                    : sendNuVotifierV2Vote(uuid, values.host, values.port, values.token, values.username);

        votePromise
            .then(response => setResponse({ message: response.data.message }))
            .catch(error => setResponse({ error: error.response?.data?.error || error.message }))
            .finally(() => {
                setIsLoading(false);
                setSubmitting(false);
            });
    };

    return (
        <ServerContentBlock title={'Votifier Test'}>
            {response && (
                <div css={tw`mb-4`}>
                    {response.message && <Alert type={'success'}>{response.message}</Alert>}
                    {response.error && <Alert type={'danger'}>{response.error}</Alert>}
                </div>
            )}
            <div css={tw`mb-8`}>
                <TitledGreyBox title={'Information'}>
                    <p css={tw`mb-4`}>This form allows you to send test votes to a server using the Votifier plugin.<br />Enter the necessary details including the host address, port, and your username. If you are using Classic Votifier or NuVotifier, you will also need to provide the public key. For NuVotifier v2, you will need to provide a token instead of the public key.
                    </p>
                    <p css={tw`mb-4`}>
                        <strong>How to obtain the Public Key:</strong> The public key of the Votifier server can be found at <strong>plugins/Votifier/rsa/public.key</strong>.<br />
                        <strong>How to obtain the Token:</strong> The token for the Votifier server can be found in the <strong>plugins/Votifier/config.yml</strong>.
                    </p>
                    <p css={tw`mb-4`}>
                        For more information, visit the <a href="https://www.spigotmc.org/resources/nuvotifier.13449/" css={tw`text-blue-500 hover:text-blue-700`} target="_blank" rel="noopener noreferrer">NuVotifier plugin page</a> or the <a href="https://github.com/NuVotifier/NuVotifier/wiki/Setup-Guide" css={tw`text-blue-500 hover:text-blue-700`} target="_blank" rel="noopener noreferrer">Setup Guide</a>.
                    </p>
                </TitledGreyBox>
            </div>
            <SpinnerOverlay visible={isLoading} fixed />
            <Formik
                initialValues={{
                    host: '',
                    port: '',
                    publicKey: '',
                    token: '',
                    username: '',
                    voteType: 'classic',
                }}
                validationSchema={Yup.object().shape({
                    host: Yup.string().required('Host is required'),
                    port: Yup.string().required('Port is required'),
                    publicKey: Yup.string().when('voteType', {
                        is: (val: string) => val !== 'nuvotifierv2',
                        then: Yup.string().required('Public Key is required'),
                    }),
                    token: Yup.string().when('voteType', {
                        is: 'nuvotifierv2',
                        then: Yup.string().required('Token is required'),
                    }),
                    username: Yup.string().required('Username is required'),
                    voteType: Yup.string().required('Vote Type is required'),
                })}
                onSubmit={submit}
            >
                <VotifierTestBox />
            </Formik>
        </ServerContentBlock>
    );
};

export default VotifierTestContainer;
