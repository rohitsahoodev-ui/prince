import http from '@/api/http';

export const sendClassicVotifierVote = (uuid: string, host: string, port: string, publicKey: string, username: string): Promise<any> => {
    return http.post(`/api/client/servers/${uuid}/votifer/classic`, { host, port, publicKey, username });
};

export const sendNuVotifierVote = (uuid: string, host: string, port: string, publicKey: string, username: string): Promise<any> => {
    return http.post(`/api/client/servers/${uuid}/votifer/nu`, { host, port, publicKey, username });
};

export const sendNuVotifierV2Vote = (uuid: string, host: string, port: string, token: string, username: string): Promise<any> => {
    return http.post(`/api/client/servers/${uuid}/votifer/nu/v2`, { host, port, token, username });
};
